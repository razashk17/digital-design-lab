const gate = document.getElementById("gate");
const buttonA = document.getElementById("a");
const buttonB = document.getElementById("b");
const output = document.getElementById("output");
const inputBRow = document.getElementById("input-b-row");

let A = 0;
let B = 0;

function calculate() {
  let result;

  switch (gate.value) {
    case "AND":
      result = A & B;
      break;
    case "OR":
      result = A | B;
      break;
    case "NOT":
      result = A ? 0 : 1;
      break;
    case "NAND":
      result = (A & B) ? 0 : 1;
      break;
    case "NOR":
      result = (A | B) ? 0 : 1;
      break;
    case "XOR":
      result = A ^ B;
      break;
    case "XNOR":
      result = A === B ? 1 : 0;
      break;
    default:
      result = 0;
  }

  output.textContent = result;
  buttonA.textContent = A;
  buttonB.textContent = B;

  // The NOT gate uses only Input A.
  inputBRow.hidden = gate.value === "NOT";
}

buttonA.addEventListener("click", () => {
  A = A ? 0 : 1;
  calculate();
});

buttonB.addEventListener("click", () => {
  B = B ? 0 : 1;
  calculate();
});

gate.addEventListener("change", calculate);

calculate();
